Create a par set from the enclosed RAR files.

Make seven par archives (PAR and P01-P07).

Delete P02-P05 and P07 (leaving you with PAR, P01 and P06).

Delete files r05 and r59

Try to recover. It can't.